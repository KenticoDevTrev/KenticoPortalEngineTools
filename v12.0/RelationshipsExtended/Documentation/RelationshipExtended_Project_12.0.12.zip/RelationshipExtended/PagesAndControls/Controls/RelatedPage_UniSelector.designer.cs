﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_RelatedPage_UniSelector
{
    protected global::System.Web.UI.WebControls.DropDownList ddlCurrentNodeDirection;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniSelector_UniSelector CustomUniSelector;
}