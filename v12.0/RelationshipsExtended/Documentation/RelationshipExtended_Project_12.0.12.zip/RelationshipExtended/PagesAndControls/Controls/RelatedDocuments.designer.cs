﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_RelatedDocuments
{
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUpdate;
    protected global::CMS.Base.Web.UI.MessagesPlaceHolder plcMess;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_UniGrid UniGridRelationship;
    protected global::System.Web.UI.WebControls.HiddenField hdnSelectedNodeId;
}