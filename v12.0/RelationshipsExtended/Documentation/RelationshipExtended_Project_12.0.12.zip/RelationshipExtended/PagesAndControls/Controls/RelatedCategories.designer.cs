﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_RelatedCategories
{
    protected global::System.Web.UI.UpdatePanel pnlCategoryExpandContract;
    protected global::System.Web.UI.WebControls.Panel pnlSearchFilter;
    protected global::System.Web.UI.WebControls.Button btnSearch;
    protected global::System.Web.UI.WebControls.Panel pnlTreeButtons;
    protected global::System.Web.UI.WebControls.Button btnExpandChecked;
    protected global::System.Web.UI.WebControls.Button btnExpandAll;
    protected global::System.Web.UI.WebControls.Button btnCollapseAll;
    protected global::System.Web.UI.WebControls.TreeView tvwCategoryTree;
    protected global::System.Web.UI.WebControls.Button btnAddCategories;
    protected global::System.Web.UI.WebControls.TextBox tbxOnlyLeafSelectable;
    protected global::System.Web.UI.WebControls.TextBox tbxParentSelectsChildren;
}

