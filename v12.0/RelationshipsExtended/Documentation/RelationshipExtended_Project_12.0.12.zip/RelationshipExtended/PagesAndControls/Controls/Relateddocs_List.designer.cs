﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_Relateddocs_List
{
    protected global::System.Web.UI.WebControls.Panel pnlContent;
    protected global::CMS.Base.Web.UI.MessagesPlaceHolder plcMessages;
    protected global::Compiled_CMSModules_RelationshipsExtended_Controls_RelatedDocuments relatedDocuments;

}