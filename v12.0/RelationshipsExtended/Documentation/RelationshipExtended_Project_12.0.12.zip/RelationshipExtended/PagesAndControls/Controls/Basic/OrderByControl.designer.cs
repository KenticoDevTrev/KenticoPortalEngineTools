﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_Basic_OrderByControl
{
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUpdate;
    protected global::System.Web.UI.WebControls.HiddenField hdnIndices;
    protected global::System.Web.UI.WebControls.PlaceHolder plcOrderBy;
}