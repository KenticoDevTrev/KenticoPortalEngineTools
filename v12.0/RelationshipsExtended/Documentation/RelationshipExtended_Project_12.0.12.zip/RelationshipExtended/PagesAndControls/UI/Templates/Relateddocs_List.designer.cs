﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_Templates_Relateddocs_List
{
    protected global::System.Web.UI.WebControls.Content plcBeforeContent;
    protected global::Compiled_CMSModules_RelationshipsExtended_Controls_EditMenu menuElem;
    protected global::CMS.Base.Web.UI.CMSDocumentPanel pnlDocInfo;
    protected global::System.Web.UI.WebControls.Content cntBody;
    protected global::System.Web.UI.WebControls.Panel pnlContent;
    protected global::CMS.Base.Web.UI.MessagesPlaceHolder plcMessages;
    protected global::Compiled_CMSModules_RelationshipsExtended_FormControls_Relationships_RelatedDocuments relatedDocuments;

}