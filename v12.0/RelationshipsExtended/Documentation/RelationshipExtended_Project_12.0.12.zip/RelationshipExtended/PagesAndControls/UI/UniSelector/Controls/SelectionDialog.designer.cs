﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_UniSelector_Controls_SelectionDialog
{
    protected global::System.Web.UI.WebControls.Panel pnlBody;
    protected global::System.Web.UI.WebControls.Panel pnlFilter;
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUpdate;
    protected global::System.Web.UI.WebControls.Panel pnlSearch;
    protected global::CMS.Base.Web.UI.LocalizedLabel lblSearch;
    protected global::CMS.Base.Web.UI.CMSTextBox txtSearch;
    protected global::CMS.Base.Web.UI.LocalizedButton btnSearch;
    protected global::System.Web.UI.WebControls.Panel pnlAll;
    protected global::CMS.Base.Web.UI.LocalizedButton lnkSelectAll;
    protected global::CMS.Base.Web.UI.LocalizedButton lnkDeselectAll;
    protected global::System.Web.UI.WebControls.Panel pnlContent;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_UniGrid uniGrid;
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlHidden;
    protected global::System.Web.UI.WebControls.HiddenField hidItem;

}