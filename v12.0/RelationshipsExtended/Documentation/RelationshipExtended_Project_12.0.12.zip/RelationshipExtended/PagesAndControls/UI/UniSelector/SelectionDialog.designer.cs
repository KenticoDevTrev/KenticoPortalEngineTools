﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_UniSelector_SelectionDialog
{
    protected global::System.Web.UI.WebControls.Content cntContent;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniSelector_Controls_SelectionDialog selectionDialog;
}