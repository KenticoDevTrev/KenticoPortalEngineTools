﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_Pager_UIPager
{
    protected global::CMS.DocumentEngine.Web.UI.UniPager pagerElem;
    protected global::CMS.Base.Web.UI.LocalizedLabel lblPage;
    protected global::CMS.Base.Web.UI.CMSTextBox txtPage;
    protected global::CMS.Base.Web.UI.CMSDropDownList drpPage;
    protected global::System.Web.UI.WebControls.PlaceHolder plcPreviousPage;
    protected global::System.Web.UI.WebControls.PlaceHolder plcPreviousGroup;
    protected global::System.Web.UI.WebControls.PlaceHolder plcPageNumbers;
    protected global::System.Web.UI.WebControls.PlaceHolder plcNextGroup;
    protected global::System.Web.UI.WebControls.PlaceHolder plcNextPage;
    protected global::System.Web.UI.WebControls.PlaceHolder plcDirectPage;
    protected global::System.Web.UI.WebControls.PlaceHolder plcPageSize;
    protected global::CMS.Base.Web.UI.LocalizedLabel lblPageSize;
    protected global::CMS.Base.Web.UI.CMSDropDownList drpPageSize;
}