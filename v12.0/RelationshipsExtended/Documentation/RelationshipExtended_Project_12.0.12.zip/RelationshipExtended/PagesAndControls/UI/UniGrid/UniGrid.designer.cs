﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_UniGrid
{
    protected global::CMS.Base.Web.UI.MessagesPlaceHolder plcMess;
    protected global::System.Web.UI.WebControls.PlaceHolder plcContextMenu;
    protected global::System.Web.UI.WebControls.Panel pnlHeader;
    protected global::System.Web.UI.WebControls.PlaceHolder plcFilter;
    protected global::System.Web.UI.WebControls.PlaceHolder plcFilterForm;
    protected global::CMS.FormEngine.Web.UI.FilterForm filterForm;
    protected global::System.Web.UI.WebControls.Label lblInfo;
    protected global::System.Web.UI.WebControls.Panel pnlContent;
    protected global::CMS.Base.Web.UI.UIGridView UniUiGridView;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_Pager_UIPager pagerElem;
    protected global::System.Web.UI.WebControls.HiddenField hidSelection;
    protected global::System.Web.UI.WebControls.HiddenField hidSelectionHash;
    protected global::System.Web.UI.WebControls.HiddenField hidCmdName;
    protected global::System.Web.UI.WebControls.HiddenField hidCmdArg;
    protected global::System.Web.UI.WebControls.HiddenField hidActions;
    protected global::System.Web.UI.WebControls.HiddenField hidActionsHash;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_Controls_MassActions ctrlMassActions;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_Controls_AdvancedExport advancedExportElem;
}