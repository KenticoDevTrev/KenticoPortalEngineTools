﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_PageElements_Help
{
    protected global::System.Web.UI.WebControls.HyperLink lnkHelp;
    protected global::System.Web.UI.WebControls.PlaceHolder plcIcon;
    protected global::System.Web.UI.HtmlControls.HtmlGenericControl iconHelp;
}