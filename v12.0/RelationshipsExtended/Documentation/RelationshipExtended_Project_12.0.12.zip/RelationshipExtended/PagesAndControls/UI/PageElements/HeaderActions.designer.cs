﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_PageElements_HeaderActions
{
    protected global::System.Web.UI.WebControls.PlaceHolder plcMenu;
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUp;
    protected global::System.Web.UI.WebControls.Panel pnlActions;
    protected global::System.Web.UI.WebControls.Panel pnlAdditionalControls;
    protected global::System.Web.UI.WebControls.PlaceHolder plcAdditionalControls;
    protected global::System.Web.UI.WebControls.Panel pnlClear;
}