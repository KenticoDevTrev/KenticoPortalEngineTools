﻿public partial class Compiled_CMSModules_RelationshipsExtended_FormControls_AdvancedManyToManySelector_AdvancedManyToManySelector
{
    protected global::System.Web.UI.WebControls.Panel pnlPreviewOnly;
    protected global::CMS.FormEngine.Web.UI.FormControl frmFormControl;
}