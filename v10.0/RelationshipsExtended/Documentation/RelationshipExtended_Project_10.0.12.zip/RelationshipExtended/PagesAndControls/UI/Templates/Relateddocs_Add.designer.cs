﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_Templates_Relateddocs_Add
{
    protected global::System.Web.UI.WebControls.Content pnlContent;
    protected global::Compiled_CMSModules_RelationshipsExtended_Controls_Relationships_AddRelatedDocument addRelatedDocument;

}