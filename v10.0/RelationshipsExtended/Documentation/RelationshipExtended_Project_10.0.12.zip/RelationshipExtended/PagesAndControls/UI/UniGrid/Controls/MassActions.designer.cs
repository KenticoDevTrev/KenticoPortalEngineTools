﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_Controls_MassActions
{
    protected global::System.Web.UI.HtmlControls.HtmlGenericControl divMessages;
    protected global::CMS.Base.Web.UI.CMSDropDownList drpScope;
    protected global::CMS.Base.Web.UI.CMSDropDownList drpAction;
    protected global::CMS.Base.Web.UI.CMSButton btnOk;
}