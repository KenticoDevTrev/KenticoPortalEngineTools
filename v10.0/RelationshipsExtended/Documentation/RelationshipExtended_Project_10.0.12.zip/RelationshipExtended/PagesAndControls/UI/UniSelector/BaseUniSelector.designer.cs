﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_UniSelector_BaseUniSelector
{
    protected global::System.Web.UI.WebControls.Label lblStatus;
    protected global::System.Web.UI.WebControls.PlaceHolder plcButtonSelect;
    protected global::CMS.Base.Web.UI.LocalizedButton btnDialog;
    protected global::System.Web.UI.WebControls.PlaceHolder plcTextBoxSelect;
    protected global::CMS.Base.Web.UI.CMSTextBox txtSingleSelect;
    protected global::CMS.UIControls.ObjectTransformation objTransform;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton btnSelect;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton btnEdit;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton btnNew;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton btnClear;
    protected global::System.Web.UI.WebControls.PlaceHolder plcDropdownSelect;
    protected global::CMS.Base.Web.UI.ExtendedDropDownList drpSingleSelect;
    protected global::System.Web.UI.WebControls.PlaceHolder pnlAutocomplete;
    protected global::CMS.Base.Web.UI.CMSTextBox txtAutocomplete;
    protected global::System.Web.UI.HtmlControls.HtmlGenericControl btnAutocomplete;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton btnDropEdit;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton btnDropNew;
    protected global::System.Web.UI.WebControls.Panel pnlGrid;
    protected global::System.Web.UI.WebControls.PlaceHolder plcContextMenu;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniGrid_UniGrid uniGrid;
    protected global::System.Web.UI.HtmlControls.HtmlGenericControl UniSelectorSpacer;
    protected global::CMS.Base.Web.UI.CMSMoreOptionsButton btnRemove;
    protected global::CMS.Base.Web.UI.LocalizedButton btnAddItems;
    protected global::System.Web.UI.WebControls.Button btnRemoveSelected;
    protected global::CMS.Base.Web.UI.LocalizedLabel lblDisabledAddButtonExplanationText;
    protected global::System.Web.UI.WebControls.HiddenField hdnDialogSelect;
    protected global::System.Web.UI.WebControls.HiddenField hdnIdentifier;
    protected global::System.Web.UI.WebControls.HiddenField hiddenField;
    protected global::System.Web.UI.WebControls.HiddenField hiddenSelected;
    protected global::System.Web.UI.WebControls.HiddenField hdnHash;
    protected global::System.Web.UI.WebControls.HiddenField hdnValue;
}