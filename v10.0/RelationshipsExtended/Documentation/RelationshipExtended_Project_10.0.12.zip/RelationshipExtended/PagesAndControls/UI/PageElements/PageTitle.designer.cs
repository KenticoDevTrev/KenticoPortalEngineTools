﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_PageElements_PageTitle
{
    protected global::System.Web.UI.WebControls.Panel pnlBody;
    protected global::System.Web.UI.WebControls.Panel pnlTitle;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_PageElements_Help helpElem;
    protected global::System.Web.UI.WebControls.PlaceHolder plcMisc;
    protected global::System.Web.UI.WebControls.Panel pnlMaximize;
    protected global::System.Web.UI.HtmlControls.HtmlGenericControl btnMaximize;
    protected global::System.Web.UI.WebControls.Panel pnlClose;
    protected global::System.Web.UI.HtmlControls.HtmlGenericControl btnClose;
    protected global::CMS.Base.Web.UI.LocalizedHeading headTitle;
    protected global::System.Web.UI.WebControls.Label lblTitleInfo;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_PageElements_BreadCrumbs breadcrumbs;
}