﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_PageElements_BreadCrumbs
{
    protected global::System.Web.UI.WebControls.Panel pnlBreadCrumbs;
    protected global::System.Web.UI.WebControls.PlaceHolder plcBreadcrumbs;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_PageElements_Help helpBreadcrumbs;
}