﻿public partial class Compiled_CMSModules_RelationshipsExtended_UI_UniControls_UniButton
{
    protected global::System.Web.UI.WebControls.HyperLink hyperLink;
    protected global::System.Web.UI.WebControls.Image image;
    protected global::System.Web.UI.WebControls.Label lblText;
    protected global::CMS.Base.Web.UI.CMSButton btn;
}