﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_Relationships_AddRelatedDocument
{
    protected global::System.Web.UI.WebControls.Panel pnlContainer;
    protected global::CMS.Base.Web.UI.MessagesPlaceHolder plcMess;
    protected global::System.Web.UI.WebControls.Label lblLeftNode;
    protected global::System.Web.UI.WebControls.Panel pnlLeftSelectedNode;
    protected global::CMS.Base.Web.UI.CMSTextBox txtLeftNode;
    protected global::CMS.Base.Web.UI.LocalizedButton btnLeftNode;
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUpdate;
    protected global::System.Web.UI.WebControls.Label lblRelName;
    protected global::Compiled_CMSModules_RelationshipsExtended_FormControls_Relationships_SelectRelationshipNames relNameSelector;
    protected global::System.Web.UI.WebControls.Label lblRightNode;
    protected global::System.Web.UI.WebControls.Panel pnlRightSelectedNode;
    protected global::CMS.Base.Web.UI.CMSTextBox txtRightNode;
    protected global::CMS.Base.Web.UI.LocalizedButton btnRightNode;
    protected global::CMS.Base.Web.UI.LocalizedButton btnSwitchSides;
    protected global::CMS.FormEngine.Web.UI.FormSubmitButton btnOk;
    protected global::System.Web.UI.WebControls.HiddenField hdnSelectedNodeId;
    protected global::System.Web.UI.WebControls.HiddenField hdnCurrentOnLeft;
}