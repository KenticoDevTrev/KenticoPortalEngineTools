﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_EditMenu
{
    protected global::System.Web.UI.WebControls.PlaceHolder plcMenu;
    protected global::CMS.Base.Web.UI.CMSPanel pnlContainer;
    protected global::System.Web.UI.WebControls.Panel pnlMenu;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_PageElements_HeaderActions menu;
    protected global::System.Web.UI.WebControls.Label lblInfo;
    protected global::System.Web.UI.WebControls.PlaceHolder plcControls;
    protected global::System.Web.UI.WebControls.Panel pnlRight;
    protected global::CMS.Base.Web.UI.CMSCheckBox chkEmails;
    protected global::System.Web.UI.WebControls.PlaceHolder plcAdditionalControls;
    protected global::System.Web.UI.WebControls.PlaceHolder plcDevices;
    protected global::CMS.Base.Web.UI.CMSDocumentPanel pnlDoc;
    protected global::System.Web.UI.WebControls.HiddenField hdnParam;
}