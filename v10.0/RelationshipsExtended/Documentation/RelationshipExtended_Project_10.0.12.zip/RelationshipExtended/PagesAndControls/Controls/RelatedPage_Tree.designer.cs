﻿public partial class Compiled_CMSModules_RelationshipsExtended_Controls_RelatedPage_Tree
{
    protected global::System.Web.UI.WebControls.Button btnAdd;
    protected global::System.Web.UI.WebControls.DropDownList ddlCurrentNodeDirection;
    protected global::System.Web.UI.WebControls.TreeView pageTree;
}