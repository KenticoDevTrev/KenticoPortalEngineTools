﻿public partial class Compiled_CMSModules_RelationshipsExtended_FormControls_Relationships_SelectRelationshipNames
{
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUpdate;
    protected global::Compiled_CMSModules_RelationshipsExtended_UI_UniSelector_BaseUniSelector uniSelector;
}