﻿public partial class Compiled_CMSModules_RelationshipsExtended_FormControls_AdvancedCategorySelector_AdvancedCategorySelector
{
    protected global::CMS.Base.Web.UI.CMSUpdatePanel pnlUpdate;
    protected global::System.Web.UI.WebControls.TextBox tbxDisplayValue;
    protected global::CMS.Base.Web.UI.CMSTextBox txtValue;
    protected global::AjaxControlToolkit.ModalPopupExtender mp1;
    protected global::System.Web.UI.WebControls.Panel Panel1;
    protected global::System.Web.UI.WebControls.Panel ModalContainerForClass;
    protected global::System.Web.UI.UpdatePanel pnlCategoryExpandContract;
    protected global::System.Web.UI.WebControls.Panel pnlSearchFilter;
    protected global::System.Web.UI.WebControls.Button btnSearch;
    protected global::System.Web.UI.WebControls.Panel pnlTreeButtons;
    protected global::System.Web.UI.WebControls.Button btnExpandChecked;
    protected global::System.Web.UI.WebControls.Button btnExpandAll;
    protected global::System.Web.UI.WebControls.Button btnCollapseAll;
    protected global::System.Web.UI.WebControls.TreeView tvwCategoryTree;
    protected global::System.Web.UI.WebControls.TextBox tbxSaveMode;
    protected global::System.Web.UI.WebControls.TextBox tbxDisplayValueHolder;
    protected global::System.Web.UI.WebControls.TextBox tbxOnlyLeafSelectable;
    protected global::System.Web.UI.WebControls.TextBox tbxParentSelectsChildren;
    protected global::System.Web.UI.WebControls.TextBox tbxSeparatorCharacter;
    protected global::System.Web.UI.WebControls.TextBox tbxCategoryValue;
    protected global::System.Web.UI.WebControls.Literal ltrOriginalValues;
    protected global::System.Web.UI.WebControls.Button btnSelect;
    protected global::System.Web.UI.WebControls.Button btnClose;

}